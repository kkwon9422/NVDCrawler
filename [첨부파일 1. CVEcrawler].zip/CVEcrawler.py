from urllib.request import urlopen
from bs4 import BeautifulSoup
import openpyxl
import timeit

def PagePrint(): # Save 20 CVEs to an Excel file
    for i in range(20):
        try:
            ws.append([CveId[i], Published[i], Cvss3Score[i], Cvss2Score[i], Cvss3Vector[i], Cvss2Vector[i]])
        except IndexError:
            print("End")
            return

cwenumber = input("CWE Number : ")  # CWE Number to search

start = timeit.default_timer()
StartIndex = 0
print(StartIndex)

flag = 1
wb = openpyxl.Workbook()
ws = wb.active
ws.title = 'CWE-'+ cwenumber
ws['A1'] = 'CVE-ID'
ws['B1'] = 'CVE Published'
ws['c1'] = 'CVSS Version 3 Score'
ws['d1'] = 'CVSS Version 2 Score'
ws['e1'] = 'CVSS Version 3 Vector'
ws['f1'] = 'CVSS Version 2 Vector'

while(1):
    CveId = []
    Published = []
    Cvss3Score = []
    Cvss2Score = []
    Cvss3Vector = []
    Cvss2Vector = []

    html = urlopen("https://nvd.nist.gov/vuln/search/results?form_type=Advanced&results_" # NVD CWE-cwenumber Category search form
               "type=overview&search_type=all&cwe_id=CWE-" + cwenumber + "&startIndex=" + str(StartIndex) + "")

    bsObject = BeautifulSoup(html, "html.parser") # Convert to HTML format

    try:
        bsObject.select('table[class="table table-striped table-hover"] > '
                        'tbody > tr[data-testid="vuln-row-0"]')[0].text
    except IndexError:
        break


    for i in range(0, 20): # CVE-ID crawler
        try:
            CveId.append(bsObject.select('table[class="table table-striped table-hover"] > '
                             'tbody > tr[data-testid="vuln-row-'+str(i)+'"] > th[nowrap="nowrap"] > strong > a[data-testid="vuln-detail-link-'+str(i)+'"]')[0].text)
        except IndexError:
            CveId.append(" ")
            continue

    for i in range(0, 20): # CVE Published crawler
        try:
            Published.append(bsObject.select('table[class="table table-striped table-hover"] > '
                          'tbody > tr > td > span[data-testid="vuln-published-on-'+str(i)+'"]')[0].text)
        except IndexError:
            Published.append(" ")
            continue

    for i in range(0, 20): # CVSS Version 3 Score crawler
        try:
            Cvss3Score.append(bsObject.select('table[class="table table-striped table-hover"] > '
                          'tbody > tr > td[nowrap="nowrap"] > span > a[data-testid="vuln-cvss3-link-'+str(i)+'"]')[0].text)
        except IndexError:
            Cvss3Score.append(" ")
            continue

    for i in range(0, 20): # CVSS Version 2 Score crawler
        try:
            Cvss2Score.append(bsObject.select('table[class="table table-striped table-hover"] > '
                          'tbody > tr > td[nowrap="nowrap"] > span > a[data-testid="vuln-cvss2-link-'+str(i)+'"]')[0].text)
        except IndexError:
            Cvss2Score.append(" ")
            continue

    for i in range(0, 20): # CVSS Version 3 Vector crawler
        try:
            Cvss3Vector.append(bsObject.select('table[class="table table-striped table-hover"] > '
                          'tbody > tr > td[nowrap="nowrap"] > span > a[data-testid="vuln-cvss3-link-'+str(i)+'"]')[0]['href'])
        except IndexError:
            Cvss3Vector.append(" ")
            continue
    for i in range(0, 20): # CVSS Version 2 Vector crawler
        try:
            Cvss2Vector.append(bsObject.select('table[class="table table-striped table-hover"] > '
                          'tbody > tr > td[nowrap="nowrap"] > span > a[data-testid="vuln-cvss2-link-'+str(i)+'"]')[0]['href'])
        except IndexError:
            Cvss2Vector.append(" ")
            continue

    if(flag == 0):
        print("LastPage End")
        break

    StartIndex += 20
    print(StartIndex)
    PagePrint()

PagePrint()

wb.save("CWE-" + cwenumber + ".xlsx")  # Excel file save
stop = timeit.default_timer()
print(stop - start)